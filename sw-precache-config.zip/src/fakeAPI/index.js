import { openDB } from 'idb';

export function getData(url) {
    return new Promise((resolve, reject) => {
        setTimeout(async () => {
            try {
                let response = await fetch(url);
                if (response.ok) { // если HTTP-статус в диапазоне 200-299
                    // получаем тело ответа (см. про этот метод ниже)
                    const data = await response.json();
                    /* setIDB(data) */
                    resolve(data);
                }
            } catch(err) {
                alert("Ошибка HTTP");
                reject(err);
            }
        }, 300);
    })
}

export function checkTime(dateStart, dateEnd) {
    const currentUTCDateStart = convertTimeToCurrent(dateStart);
    const currentUTCDateEnd = convertTimeToCurrent(dateEnd);
    const dateNow = new Date();
    return dateNow < currentUTCDateStart ? 'default' : dateNow < currentUTCDateEnd ? 'online' : 'past';
}

function convertTimeToCurrent(date) {
    const UTCDate = new Date(Date.parse(`${date}Z`));
    const hours = UTCDate.getHours();
    const minutes = UTCDate.getMinutes();
    const dateNow = new Date();
    return new Date(dateNow.getFullYear(), dateNow.getMonth(), dateNow.getDate(), hours, minutes);
}

export function getFormatTime(date) {
    const UTCDate = new Date(Date.parse(`${date}Z`));
    const hours = UTCDate.getHours();
    const minutes = UTCDate.getMinutes();
    const formattedTime = [
        hours.toString().padStart(2, '0'),
        minutes.toString().padStart(2, '0')
    ].join(':');
    return formattedTime;
}

async function setIDB(data) {
    // Storing JSON as string in indexDB
  const db1 = await openDB('db1', 1);
  /* db1.add('store1', 'hello world', 'message');
  db1.add('store1', true, 'delivered');
  db1.close(); */
}