import React, { PureComponent } from 'react';
import Event from '../components/Event/Event';
import Loader from '../components/Loader/Loader';
import { getData, getFormatTime, checkTime } from '../fakeAPI/index';

class Main extends PureComponent {
    state = {
        events: [],
        loader: true
    }

    async componentDidMount() {
        const result = await getData('./db.json');
        
        this.setState({
            events: result.collection[0].events,
            loader: false
        });
    }

    render() {
        const {events, loader} = this.state;  
        return (
            <div className="App">
                <header className="App-header">
                    <h1>Расписание мероприятий</h1>
                    {
                        events.length !== 0 ? events.map((item, index) => 
                            <Event 
                                key={`${item.id}-${item.folder}`} 
                                timeStart={getFormatTime(item.timeStart)} 
                                timeEnd={getFormatTime(item.timeEnd)} 
                                info={item.info}
                                delay={index}
                                status={checkTime(item.timeStart, item.timeEnd)}
                            />
                        ) : loader ? <Loader /> : <p>Нету мероприятий</p>
                    }
                </header>
            </div>
        )
    };
}

export default Main;