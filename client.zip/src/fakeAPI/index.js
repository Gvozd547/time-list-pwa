export function getData(url) {
    return new Promise((resolve) => {
        setTimeout(async () => {
            let response = await fetch(url);
            if (response.ok) { // если HTTP-статус в диапазоне 200-299
                // получаем тело ответа (см. про этот метод ниже)
                resolve(await response.json());
            }
            else {
                alert("Ошибка HTTP: " + response.status);
            }
        }, 3000);
    })
}