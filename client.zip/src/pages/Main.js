import React from 'react';
import Event from '../components/Event/Event';
import Loader from '../components/Loader/Loader';
import { getData } from '../fakeAPI/index';

class Main extends React.Component {
    state = {
        events: [],
        loader: true
    }

    async componentDidMount() {
        const result = await getData('./db.json');
        
        this.setState({
            events: result.collection[0].events,
            loader: false
        });
    }

    render() {
        const {events, loader} = this.state;  
        return (
            <div className="App">
                <header className="App-header">
                    <h1>Расписание мероприятий</h1>
                    {
                        events.length !== 0 ? events.map((item, index) => 
                            <Event 
                                key={`${item.id}-${item.folder}`} 
                                timeStart={item.timeStart} 
                                timeEnd={item.timeEnd} 
                                info={item.info}
                                delay={index}
                            />
                        ) : loader ? <Loader /> : <p>Нету мероприятий</p>
                    }
                </header>
            </div>
        )
    };
}

export default Main;